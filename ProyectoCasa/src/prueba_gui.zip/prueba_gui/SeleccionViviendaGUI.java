package prueba_gui;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SeleccionViviendaGUI extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SeleccionViviendaGUI frame = new SeleccionViviendaGUI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SeleccionViviendaGUI() {
        setTitle("Configuración Inicial - Smart Home");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 850, 550);
        setLocationRelativeTo(null); // Centrar en pantalla
        
        contentPane = new JPanel();
        contentPane.setBackground(new Color(102, 153, 0)); // Gris claro minimalista
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null); // Layout absoluto típico de Window Builder

        // --- TÍTULO PRINCIPAL ---
        JLabel lblTitulo = new JLabel("Selecciona tu Tipo de Vivienda");
        lblTitulo.setForeground(new Color(30, 58, 138)); // Azul oscuro
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(-186, 28, 814, 40);
        contentPane.add(lblTitulo);

        JLabel lblSubtitulo = new JLabel("Configuraremos el simulador energético basándonos en tu elección");
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setForeground(Color.DARK_GRAY);
        lblSubtitulo.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblSubtitulo.setBounds(-154, 79, 814, 20);
        contentPane.add(lblSubtitulo);

        // --- OPCIÓN 1: CASA PEQUEÑA ---
        JPanel panelPequena = new JPanel();
        panelPequena.setBorder(new LineBorder(new Color(200, 200, 200), 2, true));
        panelPequena.setBackground(new Color(192, 192, 192));
        panelPequena.setBounds(34, 166, 236, 268);
        contentPane.add(panelPequena);
        panelPequena.setLayout(null);

        JLabel lblImgPequena = new JLabel("");
        lblImgPequena.setHorizontalAlignment(SwingConstants.CENTER);
        // Descomenta la siguiente línea y pon tu imagen 3D en la carpeta src/img/
        // lblImgPequena.setIcon(new ImageIcon(SeleccionViviendaGUI.class.getResource("/img/casa_pequena.png")));
        lblImgPequena.setBounds(10, 11, 216, 127);
        lblImgPequena.setOpaque(true);
        lblImgPequena.setBackground(new Color(220, 220, 220)); // Placeholder gris temporal
        lblImgPequena.setText("casa Pequeña"); // Texto placeholder
        panelPequena.add(lblImgPequena);

        JLabel lblTitPequena = new JLabel("Casa Pequeña");
        lblTitPequena.setForeground(new Color(30, 58, 138));
        lblTitPequena.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitPequena.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitPequena.setBounds(10, 149, 220, 25);
        panelPequena.add(lblTitPequena);

        JLabel lblDescPequena = new JLabel("<html><center>1-2 personas<br>Hasta 5 dispositivos</center></html>");
        lblDescPequena.setHorizontalAlignment(SwingConstants.CENTER);
        lblDescPequena.setFont(new Font("Arial", Font.PLAIN, 13));
        lblDescPequena.setBounds(10, 173, 200, 40);
        panelPequena.add(lblDescPequena);

        JButton btnPequena = new JButton("Seleccionar");
        btnPequena.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirDashboard(5); // Pasa el límite de dispositivos
            }
        });
        btnPequena.setForeground(Color.WHITE);
        btnPequena.setBackground(new Color(16, 185, 129)); // Verde Esmeralda
        btnPequena.setFont(new Font("Arial", Font.BOLD, 14));
        btnPequena.setBounds(30, 223, 170, 34);
        panelPequena.add(btnPequena);

        // --- OPCIÓN 2: CASA MEDIANA ---
        JPanel panelMediana = new JPanel();
        panelMediana.setLayout(null);
        panelMediana.setBorder(new LineBorder(new Color(200, 200, 200), 2, true));
        panelMediana.setBackground(new Color(192, 192, 192));
        panelMediana.setBounds(305, 130, 220, 300);
        contentPane.add(panelMediana);

        JLabel lblImgMediana = new JLabel("");
        lblImgMediana.setHorizontalAlignment(SwingConstants.CENTER);
        // lblImgMediana.setIcon(new ImageIcon(SeleccionViviendaGUI.class.getResource("/img/casa_mediana.png")));
        lblImgMediana.setOpaque(true);
        lblImgMediana.setText("casa Mediana");
        lblImgMediana.setBackground(new Color(220, 220, 220));
        lblImgMediana.setBounds(10, 11, 200, 150);
        panelMediana.add(lblImgMediana);

        JLabel lblTitMediana = new JLabel("Casa Mediana");
        lblTitMediana.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitMediana.setForeground(new Color(30, 58, 138));
        lblTitMediana.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitMediana.setBounds(10, 172, 200, 25);
        panelMediana.add(lblTitMediana);

        JLabel lblDescMediana = new JLabel("<html><center>3-4 personas<br>Hasta 15 dispositivos</center></html>");
        lblDescMediana.setHorizontalAlignment(SwingConstants.CENTER);
        lblDescMediana.setFont(new Font("Arial", Font.PLAIN, 13));
        lblDescMediana.setBounds(10, 197, 200, 40);
        panelMediana.add(lblDescMediana);

        JButton btnMediana = new JButton("Seleccionar");
        btnMediana.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirDashboard(15);
            }
        });
        btnMediana.setForeground(Color.WHITE);
        btnMediana.setFont(new Font("Arial", Font.BOLD, 14));
        btnMediana.setBackground(new Color(16, 185, 129));
        btnMediana.setBounds(35, 248, 150, 40);
        panelMediana.add(btnMediana);

        // --- OPCIÓN 3: CASA GRANDE ---
        JPanel panelGrande = new JPanel();
        panelGrande.setLayout(null);
        panelGrande.setBorder(new LineBorder(new Color(200, 200, 200), 2, true));
        panelGrande.setBackground(new Color(192, 192, 192));
        panelGrande.setBounds(550, 84, 276, 346);
        contentPane.add(panelGrande);

        JLabel lblImgGrande = new JLabel("");
        lblImgGrande.setHorizontalAlignment(SwingConstants.CENTER);
        // lblImgGrande.setIcon(new ImageIcon(SeleccionViviendaGUI.class.getResource("/img/casa_grande.png")));
        lblImgGrande.setOpaque(true);
        lblImgGrande.setText("casa Grande");
        lblImgGrande.setBackground(new Color(220, 220, 220));
        lblImgGrande.setBounds(10, 11, 256, 150);
        panelGrande.add(lblImgGrande);

        JLabel lblTitGrande = new JLabel("Casa Grande");
        lblTitGrande.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitGrande.setForeground(new Color(30, 58, 138));
        lblTitGrande.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitGrande.setBounds(42, 172, 200, 25);
        panelGrande.add(lblTitGrande);

        JLabel lblDescGrande = new JLabel("<html><center>Residencia amplia<br>Dispositivos ilimitados</center></html>");
        lblDescGrande.setHorizontalAlignment(SwingConstants.CENTER);
        lblDescGrande.setFont(new Font("Arial", Font.PLAIN, 13));
        lblDescGrande.setBounds(42, 197, 200, 40);
        panelGrande.add(lblDescGrande);

        JButton btnGrande = new JButton("Seleccionar");
        btnGrande.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirDashboard(999); // Simula ilimitados
            }
        });
        btnGrande.setForeground(Color.WHITE);
        btnGrande.setFont(new Font("Arial", Font.BOLD, 14));
        btnGrande.setBackground(new Color(16, 185, 129));
        btnGrande.setBounds(35, 248, 231, 61);
        panelGrande.add(btnGrande);
        
        JButton btnNewButton = new JButton("VOLVER");
        btnNewButton.setBackground(new Color(255, 51, 51));
        btnNewButton.setForeground(new Color(0, 0, 0));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton.setBounds(0, 468, 160, 22);
        contentPane.add(btnNewButton);
    }

    /**
     * Método para manejar el cambio a la ventana principal.
     */
    private void abrirDashboard(int limiteDispositivos) {
        // Aquí instanciarías tu ventana principal pasándole el límite de dispositivos
        // Ejemplo:
        // ControladorEnergiaGUI dashboard = new ControladorEnergiaGUI(limiteDispositivos);
        // dashboard.setVisible(true);
        
        // Cierra esta ventana de selección
        this.dispose();
        System.out.println("Se ha seleccionado una vivienda con límite de: " + limiteDispositivos + " dispositivos.");
    }
}