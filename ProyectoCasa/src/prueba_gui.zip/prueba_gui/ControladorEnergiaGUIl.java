package prueba_gui;



	import java.awt.Color;
	import java.awt.EventQueue;
	import java.awt.Font;
	import java.awt.GradientPaint;
	import java.awt.Graphics;
	import java.awt.Graphics2D;
	import java.awt.RenderingHints;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JPanel;
	import javax.swing.border.EmptyBorder;
	import javax.swing.JCheckBox;
	import javax.swing.SwingConstants;

	public class ControladorEnergiaGUIl extends JFrame {

	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private JPanel contentPane;

	    public static void main(String[] args) {
	        EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                try {
	                    ControladorEnergiaGUIl frame = new ControladorEnergiaGUIl();
	                    frame.setVisible(true);
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	        });
	    }

	    public ControladorEnergiaGUIl() {
	        setTitle("Smart Home Energy UI");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setBounds(100, 100, 410, 800); // Dimensiones simulando un smartphone
	        setLocationRelativeTo(null);
	        setResizable(false);

	        // Fondo personalizado con degradado difuminado (estilo dark eco)
	        contentPane = new JPanel() {
	            @Override
	            protected void paintComponent(Graphics g) {
	                super.paintComponent(g);
	                Graphics2D g2d = (Graphics2D) g;
	                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	                
	                // Fondo oscuro base
	                GradientPaint fondoBase = new GradientPaint(0, 0, new Color(22, 26, 23), 0, getHeight(), new Color(14, 15, 14));
	                g2d.setPaint(fondoBase);
	                g2d.fillRect(0, 0, getWidth(), getHeight());
	                
	                // Simulación de los destellos verdes difuminados (Glow effect energético)
	                g2d.setColor(new Color(76, 110, 70, 70)); // Resplandor ecológico
	                g2d.fillOval(getWidth() - 250, -50, 350, 350);
	                g2d.fillOval(-100, getHeight() - 400, 300, 300);
	            }
	        };
	        
	        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	        setContentPane(contentPane);
	        contentPane.setLayout(null); // Absolute Layout para WindowBuilder

	        // ==========================================
	        // SECCIÓN: ENCABEZADO
	        // ==========================================
	        JLabel lblSection = new JLabel("smart home");
	        lblSection.setForeground(new Color(160, 170, 160));
	        lblSection.setFont(new Font("SansSerif", Font.PLAIN, 14));
	        lblSection.setBounds(30, 30, 150, 20);
	        contentPane.add(lblSection);

	        JLabel lblTitle = new JLabel("<html>Mi consumo<br>inteligente</html>");
	        lblTitle.setForeground(Color.WHITE);
	        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 32));
	        lblTitle.setBounds(30, 55, 300, 80);
	        contentPane.add(lblTitle);

	        // ==========================================
	        // TARJETA 1: "Modo Eco" (Izquierda)
	        // ==========================================
	        PanelRedondeado cardEco = new PanelRedondeado(24, new Color(40, 44, 41));
	        cardEco.setBounds(30, 160, 160, 200);
	        contentPane.add(cardEco);
	        cardEco.setLayout(null);

	        JLabel lblEcoTitle = new JLabel("Resumen");
	        lblEcoTitle.setFont(new Font("SansSerif", Font.PLAIN, 15));
	        lblEcoTitle.setForeground(Color.WHITE);
	        lblEcoTitle.setBounds(15, 15, 100, 20);
	        cardEco.add(lblEcoTitle);
	        
	        JLabel lblEcoTitle2 = new JLabel("del día");
	        lblEcoTitle2.setFont(new Font("SansSerif", Font.PLAIN, 15));
	        lblEcoTitle2.setForeground(Color.WHITE);
	        lblEcoTitle2.setBounds(15, 35, 100, 20);
	        cardEco.add(lblEcoTitle2);

	        JCheckBox chkAhorro = new JCheckBox("Modo Ahorro");
	        chkAhorro.setSelected(true);
	        chkAhorro.setFont(new Font("SansSerif", Font.PLAIN, 12));
	        chkAhorro.setForeground(new Color(30, 40, 30));
	        chkAhorro.setBackground(new Color(194, 237, 146)); // Verde claro
	        chkAhorro.setBounds(15, 75, 130, 28);
	        cardEco.add(chkAhorro);

	        JLabel lblAhorroKw = new JLabel("- 1.5 kWh");
	        lblAhorroKw.setFont(new Font("SansSerif", Font.BOLD, 14));
	        lblAhorroKw.setForeground(new Color(194, 237, 146));
	        lblAhorroKw.setBounds(15, 155, 130, 20);
	        cardEco.add(lblAhorroKw);

	        // ==========================================
	        // TARJETA 2: "Consumo General" (Derecha)
	        // ==========================================
	        PanelRedondeado cardConsumo = new PanelRedondeado(24, new Color(130, 175, 115));
	        cardConsumo.setBounds(205, 160, 160, 200);
	        contentPane.add(cardConsumo);
	        cardConsumo.setLayout(null);

	        JLabel lblConsumoTitle = new JLabel("Consumo");
	        lblConsumoTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
	        lblConsumoTitle.setForeground(new Color(25, 40, 25));
	        lblConsumoTitle.setBounds(15, 20, 130, 22);
	        cardConsumo.add(lblConsumoTitle);
	        
	        JLabel lblConsumoSub = new JLabel("Eléctrico");
	        lblConsumoSub.setFont(new Font("SansSerif", Font.BOLD, 18));
	        lblConsumoSub.setForeground(new Color(25, 40, 25));
	        lblConsumoSub.setBounds(15, 42, 130, 22);
	        cardConsumo.add(lblConsumoSub);

	        JLabel lblKwInfo = new JLabel("Tarifa Llana Actual");
	        lblKwInfo.setFont(new Font("SansSerif", Font.PLAIN, 12));
	        lblKwInfo.setForeground(new Color(40, 60, 40));
	        lblKwInfo.setBounds(15, 70, 130, 20);
	        cardConsumo.add(lblKwInfo);

	        JLabel lblTotal = new JLabel("3.2 kWh");
	        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 22));
	        lblTotal.setForeground(new Color(25, 40, 25));
	        lblTotal.setBounds(15, 150, 130, 25);
	        cardConsumo.add(lblTotal);

	        // ==========================================
	        // TARJETA 3: Termostato (Medio)
	        // ==========================================
	        PanelRedondeado cardTermostato = new PanelRedondeado(20, new Color(40, 44, 41));
	        cardTermostato.setBounds(30, 380, 335, 70);
	        contentPane.add(cardTermostato);
	        cardTermostato.setLayout(null);

	        JLabel lblTermostatoTitle = new JLabel("Climatización Central");
	        lblTermostatoTitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
	        lblTermostatoTitle.setForeground(Color.WHITE);
	        lblTermostatoTitle.setBounds(15, 15, 240, 20);
	        cardTermostato.add(lblTermostatoTitle);
	        
	        JLabel lblTemp = new JLabel("Activo  ·  Manteniendo a 22°C  ·  Auto");
	        lblTemp.setFont(new Font("SansSerif", Font.PLAIN, 11));
	        lblTemp.setForeground(new Color(140, 150, 140));
	        lblTemp.setBounds(15, 38, 240, 15);
	        cardTermostato.add(lblTemp);

	        PanelRedondeado btnControlTemp = new PanelRedondeado(30, new Color(194, 237, 146));
	        btnControlTemp.setBounds(275, 15, 40, 40);
	        cardTermostato.add(btnControlTemp);
	        btnControlTemp.setLayout(null);
	        
	        JLabel lblIconTemp = new JLabel("❄");
	        lblIconTemp.setHorizontalAlignment(SwingConstants.CENTER);
	        lblIconTemp.setBounds(0, 0, 40, 40);
	        lblIconTemp.setForeground(Color.BLACK);
	        btnControlTemp.add(lblIconTemp);

	        // ==========================================
	        // TARJETA 4: Acción General (Abajo)
	        // ==========================================
	        PanelRedondeado cardOff = new PanelRedondeado(20, new Color(40, 44, 41));
	        cardOff.setBounds(30, 470, 335, 70);
	        contentPane.add(cardOff);
	        cardOff.setLayout(null);

	        JLabel lblOffTitle = new JLabel("Apagar todo el sistema");
	        lblOffTitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
	        lblOffTitle.setForeground(Color.WHITE);
	        lblOffTitle.setBounds(15, 15, 240, 20);
	        cardOff.add(lblOffTitle);
	        
	        JLabel lblOffDesc = new JLabel("15 disp.  ·  Salir de casa  ·  Seguro");
	        lblOffDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
	        lblOffDesc.setForeground(new Color(140, 150, 140));
	        lblOffDesc.setBounds(15, 38, 240, 15);
	        cardOff.add(lblOffDesc);

	        PanelRedondeado btnPower = new PanelRedondeado(30, new Color(230, 100, 100)); // Rojo apagado
	        btnPower.setBounds(275, 15, 40, 40);
	        cardOff.add(btnPower);
	        btnPower.setLayout(null);
	        
	        JLabel lblIconPower = new JLabel("⏻");
	        lblIconPower.setHorizontalAlignment(SwingConstants.CENTER);
	        lblIconPower.setBounds(0, 0, 40, 40);
	        lblIconPower.setForeground(Color.WHITE);
	        btnPower.add(lblIconPower);
	    }}