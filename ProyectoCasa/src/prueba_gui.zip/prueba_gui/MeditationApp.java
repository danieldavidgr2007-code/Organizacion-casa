package prueba_gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class MeditationApp extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

    public static void main(String[] args) {
        try {
            MeditationApp frame = new MeditationApp();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public MeditationApp() {
        setTitle("Meditation Plan UI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 661, 734); // Dimensiones simulando un smartphone
        setLocationRelativeTo(null);
        setResizable(false);

        // Fondo personalizado con degradado difuminado
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Fondo oscuro base
                GradientPaint fondoBase = new GradientPaint(0, 0, new Color(22, 26, 23), 0, getHeight(), new Color(14, 15, 14));
                g2d.setPaint(fondoBase);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                // Simulación de los destellos verdes difuminados (Glow effect)
                g2d.setColor(new Color(76, 110, 70, 70));
                g2d.fillOval(getWidth() - 250, -50, 350, 350);
                g2d.fillOval(-100, getHeight() - 400, 300, 300);
            }
        };
        
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null); // Absolute Layout para WindowBuilder

        // ==========================================
        // SECCIÓN: ENCABEZADO
        // ==========================================
        JLabel lblCourses = new JLabel("courses");
        lblCourses.setForeground(new Color(160, 170, 160));
        lblCourses.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblCourses.setBounds(30, 30, 100, 20);
        contentPane.add(lblCourses);

        JLabel lblTitle = new JLabel("<html>Smart Home<br>plan</html>");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblTitle.setBounds(30, 55, 300, 80);
        contentPane.add(lblTitle);

        // ==========================================
        // TARJETA 1: "Plan for the day" (Izquierda)
        // ==========================================
        PanelRedondeado cardPlan = new PanelRedondeado(24, new Color(40, 44, 41));
        cardPlan.setBounds(30, 160, 160, 200);
        contentPane.add(cardPlan);
        cardPlan.setLayout(null);

        JLabel lblPlanTitle = new JLabel("Plan for");
        lblPlanTitle.setFont(new Font("SansSerif", Font.PLAIN, 15));
        lblPlanTitle.setForeground(Color.WHITE);
        lblPlanTitle.setBounds(15, 15, 100, 20);
        cardPlan.add(lblPlanTitle);
        
        JLabel lblPlanTitle2 = new JLabel("the day");
        lblPlanTitle2.setFont(new Font("SansSerif", Font.PLAIN, 15));
        lblPlanTitle2.setForeground(Color.WHITE);
        lblPlanTitle2.setBounds(15, 35, 100, 20);
        cardPlan.add(lblPlanTitle2);

        JCheckBox chkAffirmation = new JCheckBox("Affirmation");
        chkAffirmation.setSelected(true);
        chkAffirmation.setFont(new Font("SansSerif", Font.PLAIN, 12));
        chkAffirmation.setForeground(new Color(30, 40, 30));
        chkAffirmation.setBackground(new Color(194, 237, 146)); // Verde claro de la imagen
        chkAffirmation.setBounds(15, 75, 130, 28);
        cardPlan.add(chkAffirmation);

        // ==========================================
        // TARJETA 2: "Sleep Meditation" (Derecha)
        // ==========================================
        PanelRedondeado cardSleep = new PanelRedondeado(24, new Color(130, 175, 115));
        cardSleep.setBounds(333, 160, 160, 200);
        contentPane.add(cardSleep);
        cardSleep.setLayout(null);

        JLabel lblSleepTitle = new JLabel("Sleep");
        lblSleepTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblSleepTitle.setForeground(new Color(25, 40, 25));
        lblSleepTitle.setBounds(15, 20, 130, 22);
        cardSleep.add(lblSleepTitle);
        
        JLabel lblSleepSub = new JLabel("Meditation");
        lblSleepSub.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblSleepSub.setForeground(new Color(25, 40, 25));
        lblSleepSub.setBounds(15, 42, 130, 22);
        cardSleep.add(lblSleepSub);

        JLabel lblSeries = new JLabel("7 Day Audio Series");
        lblSeries.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSeries.setForeground(new Color(40, 60, 40));
        lblSeries.setBounds(15, 70, 130, 20);
        cardSleep.add(lblSeries);

        // ==========================================
        // TARJETA 3: Fila de Reproducción Inferior
        // ==========================================
        PanelRedondeado cardPlay = new PanelRedondeado(20, new Color(40, 44, 41));
        cardPlay.setBounds(30, 380, 335, 70);
        contentPane.add(cardPlay);
        cardPlay.setLayout(null);

        JLabel lblPlayTitle = new JLabel("Affirmations to close your day");
        lblPlayTitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblPlayTitle.setForeground(Color.WHITE);
        lblPlayTitle.setBounds(15, 15, 240, 20);
        cardPlay.add(lblPlayTitle);
        
        JLabel lblDuration = new JLabel("15 min  ·  Evening  ·  Relax");
        lblDuration.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblDuration.setForeground(new Color(140, 150, 140));
        lblDuration.setBounds(15, 38, 200, 15);
        cardPlay.add(lblDuration);

        // Botón circular de reproducción simulado
        PanelRedondeado btnPlay = new PanelRedondeado(30, new Color(194, 237, 146));
        btnPlay.setBounds(275, 15, 40, 40);
        cardPlay.add(btnPlay);
        btnPlay.setLayout(null);
        
        JLabel lblIcon = new JLabel("▶");
        lblIcon.setHorizontalAlignment(SwingConstants.CENTER);
        lblIcon.setBounds(0, 0, 40, 40);
        lblIcon.setForeground(Color.BLACK);
        btnPlay.add(lblIcon);
    }}