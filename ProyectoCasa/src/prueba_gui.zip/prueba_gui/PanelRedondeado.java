package prueba_gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;

// ==========================================
    // CLASE AUXILIAR: Paneles Redondeados
    // ==========================================
    class PanelRedondeado extends JPanel {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int infoRadio;
        private Color infoColor;

        public PanelRedondeado(int radio, Color color) {
            this.infoRadio = radio;
            this.infoColor = color;
            setOpaque(false); // Clave para que se vea el fondo redondeado
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(infoColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), infoRadio, infoRadio);
        }
    }
